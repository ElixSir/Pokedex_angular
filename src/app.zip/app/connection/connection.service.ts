import { Injectable } from '@angular/core';
import { catchError, Observable, of, tap } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ConnectionService {
  private connected: boolean = false;
  private refresh_token : string = "";
  private access_token : string = "";
  private expires_in : string = "";
  constructor(private http: HttpClient) {}

  teamAuthentification( url:string, email:string, password:string) : Observable<any> {
    return this.http.post<any>(url, { email: email, password: password }).pipe(
      tap(result=>
        {
          console.log(result);
          if(result["access_token"])
          {
            this.connected = true;
            this.refresh_token = result["refresh_token"];
            this.access_token = result["access_token"];
            this.expires_in = result["expires_in"];
            localStorage.setItem("connected", "true");
            localStorage.setItem("access_token", result["access_token"]);
          }
          else{
            this.connected = false;
          }

        }),
      catchError(error=> of(error))
      );
  }


  isLogged() : boolean {
    /*if(localStorage.getItem("connected"))
    {
      return true;
    }*/
    return this.connected;
  }

  getToken() : string {
    return localStorage.getItem("access_token") ?? this.access_token;
    //si nul ou undefined deuxième option
  }
}
